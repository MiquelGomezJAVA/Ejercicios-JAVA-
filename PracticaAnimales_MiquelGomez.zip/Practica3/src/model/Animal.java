/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author 100005548.joan23
 */
public class Animal {
    private String nom;
    private String raza;
    private String pais;
    private int edat;

    public Animal(String nom, String raza, String pais, int edat) {
        this.nom = nom;
        this.raza = raza;
        this.pais = pais;
        this.edat = edat;
    }

    public Animal() {
    }

    public String getNom() {
        return nom;
    }

    public String getRaza() {
        return raza;
    }

    public String getPais() {
        return pais;
    }

    public int getEdat() {
        return edat;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public void setEdat(int edat) {
        this.edat = edat;
    }
   
    
    
    
}
